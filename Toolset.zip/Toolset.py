# Toolset to interpolate road traffic volume in Rhode Island

import arcpy
arcpy.CheckOutExtension("3D")
# set work place
arcpy.env.workspace = r"F:\NRS 568\Toolset"

# # spatially join traffic volume to roads in RI
target_features = r"F:\NRS 568\Toolset\RIDOT_Roads_2016.shp"
join_features = r"F:\NRS 568\Toolset\Traffic_Counts.shp"
out_feature_class = r"F:\NRS 568\Toolset\RD_TC_Join.shp"

arcpy.SpatialJoin_analysis(target_features, join_features, out_feature_class)


# # Generate points along roads in RI for IDW every 250 feet
arcpy.GeneratePointsAlongLines_management('RD_TC_Join.shp', 'RD_TC_250Feet.shp', 'DISTANCE', Distance='250 feet')

if arcpy.Exists(RD_TC_250Feet.shp):
    print "Created file successfully!"
else:
    print "Shape file doesn't exist"

# Create raster of IDW for traffic volume.
# This is interpolating from 12 of the 90,0000 points created in the previous tool.
# 12 point was chosen as the tool took longer to run when more points were included in analysis.
arcpy.Idw_3d(in_point_features="RD_TC_250Feet.shp", z_field="AADTYR", out_raster="F:/NRS 568/Toolset/AADT_IDW", cell_size="30", power="2", search_radius="VARIABLE 12", in_barrier_polyline_features="")

if arcpy.Exists(AADT_IDW):
    print "Created file successfully!"
else:
    print "Raster doesn't exist"

# Convert raster to polygon to be able to run the intersect tool to overlay traffic volumes to roads
arcpy.RasterToPolygon_conversion("AADT_IDW", r"F:\NRS 568\Toolset\AADT_Polygon", "NO_SIMPLIFY", "AADTYR")
if arcpy.Exists(AADT_Polygon):
    print "Created file successfully!"
else:
    print "Shape file doesn't exist"

# Intersect roads and traffic volume polygon as overlay
inFeatures = r"F:\NRS 568\Toolset\AADT_Polygon"
print inFeatures

# Intersect tool to overlay roads and traffic volume
arcpy.Intersect_analysis(inFeatures, r"F:\NRS 568\Toolset\AADT_Intersect", "ALL", "", "INPUT")

if arcpy.Exists(AADT_Intersect):
    print "Created file successfully!"
else:
    print "Shape file doesn't exist"

